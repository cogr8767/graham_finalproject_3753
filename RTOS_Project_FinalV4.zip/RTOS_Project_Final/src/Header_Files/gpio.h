/*
 * gpio.h
 *
 *  Created on: Sep 7, 2021
 *      Author: Nick
 */

#ifndef SRC_HEADER_FILES_GPIO_H_
#define SRC_HEADER_FILES_GPIO_H_

//***********************************************************************************
// Include files
//***********************************************************************************
#include "em_gpio.h"
#include "bspconfig.h"
#include "capsense.h"

//***********************************************************************************
// defined files
//***********************************************************************************

// LEDs
#define LED0_port   gpioPortF
#define LED0_pin    4u
#define LED0_default  false   // Default false (0) = off, true (1) = on
#define LED1_port   gpioPortF
#define LED1_pin    5u
#define LED1_default  false // Default false (0) = off, true (1) = on

// User Buttons
#define PUSHB0_port  gpioPortF
#define PUSHB0_pin   6u
#define PUSHB1_port  gpioPortF
#define PUSHB1_pin   7u

//***********************************************************************************
// global variables
//***********************************************************************************


//***********************************************************************************
// function prototypes
//***********************************************************************************
void gpio_open(void);
unsigned int get_pushb0(); //gets value of btn1
unsigned int get_pushb1(); //gets value of btn1
unsigned int get_capsense_loc();      //returns capsense position 0 thru 3. default = 0;
void set_led0(int input); //sets led0
void set_led1(int input); //sets led1

#endif /* SRC_HEADER_FILES_GPIO_H_ */
