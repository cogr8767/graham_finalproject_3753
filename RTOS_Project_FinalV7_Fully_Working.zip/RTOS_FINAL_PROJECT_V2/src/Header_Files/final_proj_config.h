/*
 * final_proj_config.h
 *
 *  Created on: Nov 12, 2021
 *      Author: Collin Graham
 */

#ifndef SRC_HEADER_FILES_FINAL_PROJ_CONFIG_H_
#define SRC_HEADER_FILES_FINAL_PROJ_CONFIG_H_

//-1 = undecided
//-1.5 = may be unused
//-2 = unused
//Any natural number: set val

#define FAST_MODE

#ifndef FAST_MODE //SLOW MODE
//Other
#define DATA_STRUCTURE_VER      1

//Properties
#define GRAVITY                 8  /// [m/s^2]
#define VEHICLE_MASS            -1  /// [kg]
#define CONVERSION_EFF          -1.5/// [%]
#define FUEL_ENERGY_DENSITY     -1.5/// [kJ/g]
#define ANGLE_CHANGE_QUANTA     -2  /// [mrad]

//Initial Properties
#define INITIAL_V_X             0  /// [cm/s]
#define INITIAL_V_Y             0  /// [cm/s]
#define INITIAL_X               64  /// [mm]
#define INITIAL_Y               10  /// [mm]
#define INITIAL_FUEL_MASS       -1  /// [kg]

//Max Properties
#define MAX_THRUST              -1  /// [N]
#define MAX_LANDING_SPEED_X     3  /// [cm/s]
#define MAX_LANDING_SPEED_Y     10  /// [mm/s]
#define MAX_ACCELERATION        -1  /// [mm/s^2]
#define MAX_ACC_BLACKOUT_AFTER  10000  /// [ms] //updated to [ms] from [s]
#define BLACKOUT_DURATION       6000  /// [ms] //updated to [ms] from [s]

///NEW
#define THRUST_ACCEL            16
///NEW

//Hardware Constraints
#define XMIN                    -1  /// [cm]
#define XMAX                    -1  /// [cm]

//Configurable
enum Selected_Option {NormalMode, HardMode};

#else // FAST MODE
//Other
#define DATA_STRUCTURE_VER      1

//Properties
#define GRAVITY                 32  /// [m/s^2]
#define VEHICLE_MASS            -1  /// [kg]
#define CONVERSION_EFF          -1.5/// [%]
#define FUEL_ENERGY_DENSITY     -1.5/// [kJ/g]
#define ANGLE_CHANGE_QUANTA     -2  /// [mrad]

//Initial Properties
#define INITIAL_V_X             0  /// [cm/s]
#define INITIAL_V_Y             0  /// [cm/s]
#define INITIAL_X               64  /// [mm]
#define INITIAL_Y               10  /// [mm]
#define INITIAL_FUEL_MASS       -1  /// [kg]

//Max Properties
#define MAX_THRUST              -1  /// [N]
#define MAX_LANDING_SPEED_X     16  /// [cm/s]
#define MAX_LANDING_SPEED_Y     32  /// [mm/s]
#define MAX_ACCELERATION        -1  /// [mm/s^2]
#define MAX_ACC_BLACKOUT_AFTER  10000  /// [ms] //updated to [ms] from [s]
#define BLACKOUT_DURATION       6000  /// [ms] //updated to [ms] from [s]

///NEW
#define THRUST_ACCEL            64
///NEW

//Hardware Constraints
#define XMIN                    -1  /// [cm]
#define XMAX                    -1  /// [cm]

//Configurable
enum Selected_Option {NormalMode, HardMode};

#endif

#endif /* SRC_HEADER_FILES_FINAL_PROJ_CONFIG_H_ */
