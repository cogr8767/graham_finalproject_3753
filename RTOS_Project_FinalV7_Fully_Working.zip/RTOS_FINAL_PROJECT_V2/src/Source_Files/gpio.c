//***********************************************************************************
// Include files
//***********************************************************************************
#include "gpio.h"

//***********************************************************************************
// defined files
//***********************************************************************************


//***********************************************************************************
// global variables
//***********************************************************************************


//***********************************************************************************
// function prototypes
//***********************************************************************************


//***********************************************************************************
// functions
//***********************************************************************************

/***************************************************************************//**
 * @brief
 * configures the gpio pins
 *
 * @details
 * sets up drivestrength and pin modes for all in use gpios
 * these include the leds and the buttons
 *
 * @note
 * if any other gpio even interrupt is triggered we want to assert false because none of them should even be enabled
 *
 ******************************************************************************/
void gpio_open(void){
  //gpio initialization moved to individual tasks
  /// NEW ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++<
  //Push Button interrupts

  /// NEW ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++>
}

//push button handling
unsigned int get_pushb0(){
  if(GPIO_PinInGet(BSP_GPIO_PB0_PORT, BSP_GPIO_PB0_PIN) == 0){
      return 1;
  }
  else{
      return 0;
  }
}

unsigned int get_pushb1(){
  if(GPIO_PinInGet(BSP_GPIO_PB1_PORT, BSP_GPIO_PB1_PIN) == 0){
      return 1;
  }
  else{
      return 0;
  }
}

//cap sense handling

unsigned int get_capsense_loc(){    //0,1 = left side, 2,3 = right side, 4 = off
  CAPSENSE_Sense();
  bool temp = 0;

  for (int i = 0; i < 3; i++){
      temp = CAPSENSE_getPressed(i);
      if(temp){
          return i;
      }
  }
  return 4;
}

//led handling

void set_led0(int input) {
  if(input == 1) {
      GPIO_PinOutSet(LED0_port, LED0_pin);
  }
  else if(input == 0) {
      GPIO_PinOutClear(LED0_port, LED0_pin);
  }
}

void set_led1(int input) {
  if(input == 1) {
      GPIO_PinOutSet(LED1_port, LED1_pin);
  }
  else if(input == 0) {
      GPIO_PinOutClear(LED1_port, LED1_pin);
  }
}

