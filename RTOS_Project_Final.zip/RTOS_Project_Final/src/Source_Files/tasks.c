/***************************************************************************//**
 * @file
 * @brief Blink examples functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

#include "tasks.h"
#include "sl_simple_led.h"
#include "sl_simple_led_instances.h"
#include "os.h"

/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

static OS_TCB physics_tcb;
static OS_TCB button_tcb;
static OS_TCB capsense_tcb;
static OS_TCB lcd_tcb;
static OS_TCB led_tcb;

static CPU_STK physics_stack[NORMAL_TASK_STACK_SIZE];
static CPU_STK button_stack[NORMAL_TASK_STACK_SIZE];
static CPU_STK capsense_stack[NORMAL_TASK_STACK_SIZE];
static CPU_STK lcd_stack[NORMAL_TASK_STACK_SIZE];
static CPU_STK led_stack[NORMAL_TASK_STACK_SIZE];

OS_SEM Physics_Timer_Semaphore;
OS_SEM Capsense_Timer_Semaphore;
OS_SEM LCD_Timer_Semaphore;

OS_MUTEX Button_Presses_Mutex;
OS_MUTEX Cap_Pos_Mutex;
OS_MUTEX Pos_Ang_Data_Mutex;
OS_MUTEX Current_Thrust_Mutex;

OS_FLAG_GRP Button_Flags;
OS_FLAG_GRP LED_Flags;

OS_TMR  Cap_and_LCD_Timer;
OS_TMR  Physics_Timer;

#define  BUTTON_FLAG_0_on         0x1
#define  BUTTON_FLAG_1_on         0x2
#define  BUTTON_FLAG_0_off        0x4
#define  BUTTON_FLAG_1_off        0x8
#define  BUTTON_FLAG_ALL          (BUTTON_FLAG_0_on | BUTTON_FLAG_1_on | BUTTON_FLAG_0_off | BUTTON_FLAG_1_off)

#define LED_THRUST_CHANGE_FLAG    0x1 //tells LED task that thrust has changed: you should check it
#define LED_BLACKOUT_FLAG         0x2 //tells LED that we are blacked out, baby
#define LED_WAKEUP_FLAG           0x4 //tells LED that we woke up. time to kick some ass, baby.
#define LED_CRASH_FLAG            0x8 //tells LED that we died. :-(
#define LED_ALL_FLAGS             (LED_THRUST_CHANGE_FLAG | LED_BLACKOUT_FLAG | LED_WAKEUP_FLAG | LED_CRASH_FLAG)

/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/
static void physics_task(void *arg);
static void button_task(void *arg);
static void capsense_task(void *arg);
static void lcd_task(void *arg);
static void led_task(void *arg);
void physics_TimerCallback (void  *p_tmr, void  *p_arg);
void cap_and_lcd_TimerCallback (void  *p_tmr, void  *p_arg);

/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/
unsigned int pushb0;
unsigned int pushb1;
unsigned int capsense_loc;

/***************************************************************************//**
 * Initialize blink example.
 ******************************************************************************/
void task_init(void)
{
  RTOS_ERR err;

  ///Create Tasks
  OSTaskCreate(&physics_tcb,
               "Physics Task",
               physics_task,
               DEF_NULL,
               PHYSICS_TASK_PRIO,
               &physics_stack[0],
               (NORMAL_TASK_STACK_SIZE / 10u),
               NORMAL_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTaskCreate(&button_tcb,
               "Button Task",
               button_task,
               DEF_NULL,
               BUTTON_TASK_PRIO,
               &button_stack[0],
               (NORMAL_TASK_STACK_SIZE / 10u),
               NORMAL_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTaskCreate(&capsense_tcb,
               "Capsense Task",
               capsense_task,
               DEF_NULL,
               CAPSENSE_TASK_PRIO,
               &capsense_stack[0],
               (NORMAL_TASK_STACK_SIZE / 10u),
               NORMAL_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTaskCreate(&lcd_tcb,
               "LCD Task",
               lcd_task,
               DEF_NULL,
               LCD_TASK_PRIO,
               &lcd_stack[0],
               (NORMAL_TASK_STACK_SIZE / 10u),
               NORMAL_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTaskCreate(&led_tcb,
               "LED Task",
               led_task,
               DEF_NULL,
               LED_TASK_PRIO,
               &led_stack[0],
               (NORMAL_TASK_STACK_SIZE / 10u),
               NORMAL_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  ///Create OS Objects
  OSSemCreate(&Physics_Timer_Semaphore,
              "Physics Timer Semaphore",
              0,
              &err);

  OSSemCreate(&LCD_Timer_Semaphore,
              "LCD Timer Semaphore",
              0,
              &err);

  OSSemCreate(&Capsense_Timer_Semaphore,
              "Capsense Timer Semaphore",
              0,
              &err);

  OSMutexCreate(&Button_Presses_Mutex,
                "Button Presses Data Mutex",
                &err);

  OSMutexCreate(&Cap_Pos_Mutex,
                "Capsense Position Data Mutex",
                &err);

  OSMutexCreate(&Pos_Ang_Data_Mutex,
                "Position and Angle Data Mutex",
                &err);

  OSMutexCreate(&Current_Thrust_Mutex,
                "Current Thrust Data Mutex",
                &err);

  OSFlagCreate(&Button_Flags,
               "Button Task Flags",
               0,
               &err);

  OSFlagCreate(&LED_Flags,
               "LED Task Flags",
               0,
               &err);

  OSTmrCreate(&Physics_Timer,                 /*   Pointer to user-allocated timer.     */
              "Physics Task Post Timer",      /*   Name used for debugging.             */
              1,                              /*     0 initial delay.                   */
              5,                              /*   100 Timer Ticks period.              */            ///MAY HAVE TO BE ADJUSTED
              OS_OPT_TMR_PERIODIC,            /*   Timer is periodic.                   */
              &physics_TimerCallback,            /*   Called when timer expires.           */
              DEF_NULL,                       /*   No arguments to callback.            */
              &err);

  OSTmrCreate(&Cap_and_LCD_Timer,             /*   Pointer to user-allocated timer.     */
              "Capsense and LCD Post Timer",  /*   Name used for debugging.             */
              1,                              /*     0 initial delay.                   */
              5,                              /*   100 Timer Ticks period.              */            ///MAY HAVE TO BE ADJUSTED
              OS_OPT_TMR_PERIODIC,            /*   Timer is periodic.                   */
              &cap_and_lcd_TimerCallback,            /*   Called when timer expires.           */
              DEF_NULL,                       /*   No arguments to callback.            */
              &err);

  ///Initialization
  // LED
  GPIO_DriveStrengthSet(BSP_GPIO_LED0_PORT, gpioDriveStrengthStrongAlternateStrong);
  GPIO_DriveStrengthSet(BSP_GPIO_LED1_PORT, gpioDriveStrengthStrongAlternateStrong);
  GPIO_PinModeSet(BSP_GPIO_LED0_PORT, BSP_GPIO_LED0_PIN, gpioModePushPull, false);
  GPIO_PinModeSet(BSP_GPIO_LED1_PORT, BSP_GPIO_LED1_PIN, gpioModePushPull, false);
  // Buttons
  GPIO_PinModeSet(BSP_GPIO_PB0_PORT, BSP_GPIO_PB0_PIN, gpioModeInput, false);
  GPIO_PinModeSet(BSP_GPIO_PB1_PORT, BSP_GPIO_PB1_PIN, gpioModeInput, false);
  GPIO_IntConfig(PUSHB0_port, PUSHB0_pin, false, true, true);
  GPIO_IntConfig(PUSHB1_port, PUSHB1_pin, false, true, true);
  NVIC_EnableIRQ(GPIO_EVEN_IRQn);
  NVIC_EnableIRQ(GPIO_ODD_IRQn);
  // Capsense init in capsense_task
}

/*******************************************************************************
 **************************   TASK FUNCTIONS   *******************************
 ******************************************************************************/
static void physics_task(void *arg) {
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;

  OSTmrStart(&Physics_Timer, &err);

  while (1){

  }
}
static void button_task(void *arg) {
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;

  while (1){

  }
}

static void capsense_task(void *arg) {
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;

  OSTmrStart(&Cap_and_LCD_Timer, &err);
  CAPSENSE_Init();

  while (1){

  }
}

static void lcd_task(void *arg) {
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;

  while (1){

  }
}

static void led_task(void *arg) {
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;

  while (1){

  }
}


/*******************************************************************************
 **************************   TIMER AND ISR FUNCTIONS   *******************************
 ******************************************************************************/

//Semaphore Timer
void physics_TimerCallback (void  *p_tmr, ///this may need to be a crit sec
                        void  *p_arg) {
  /* Called when timer expires:                            */
  /*   'p_tmr' is pointer to the user-allocated timer.     */
  /*   'p_arg' is argument passed when creating the timer. */
  PP_UNUSED_PARAM(p_tmr);
  PP_UNUSED_PARAM(p_arg);
  RTOS_ERR err;

  OSSemPost (&Physics_Timer_Semaphore,
             OS_OPT_POST_ALL,
             &err);
}

void cap_and_lcd_TimerCallback (void *p_tmr, //this may need to be a crit sec
                                void *p_arg) {
  /* Called when timer expires:                            */
  /*   'p_tmr' is pointer to the user-allocated timer.     */
  /*   'p_arg' is argument passed when creating the timer. */
  PP_UNUSED_PARAM(p_tmr);
  PP_UNUSED_PARAM(p_arg);
  RTOS_ERR err;

  OSSemPost (&LCD_Timer_Semaphore,
             OS_OPT_POST_ALL,
             &err);

  OSSemPost (&Capsense_Timer_Semaphore,
             OS_OPT_POST_ALL,
             &err);
}

//GPIO Interrupts
void GPIO_EVEN_IRQHandler(void){
  uint32_t temp = GPIO_IntGet();
  GPIO_IntClear(temp);
  RTOS_ERR  err;

  ///CHANGE THIS TO FLAG SYSTEM
  //*** Post Semaphore to Speed Setpoint Task
//  OSSemPost (&,
//             OS_OPT_POST_1,
//             &err);
}

void GPIO_ODD_IRQHandler(void){ //this function is only different from the last one in that it calls a function, i just copied that functions logic into the other gpio interrupt handler
  uint32_t temp = GPIO_IntGet();
  GPIO_IntClear(temp);
  RTOS_ERR  err;

  ///CHANGE THIS TO FLAG SYSTEM
  //*** Post Semaphore to Speed Setpoint Task
//  OSSemPost (&,
//             OS_OPT_POST_ALL,
//             &err);
}


