/***************************************************************************//**
 * @file
 * @brief Blink examples functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

#ifndef TASKS_H
#define TASKS_H

#include "gpio.h"
#include "em_emu.h"
#include "public_data.h"
#include "final_proj_config.h"

#define NORMAL_TASK_STACK_SIZE      512

#define PHYSICS_TASK_PRIO           10    //double check this is the highest prio
#define BUTTON_TASK_PRIO            13
#define CAPSENSE_TASK_PRIO          13
#define LCD_TASK_PRIO               11
#define LED_TASK_PRIO               12

#ifndef PUBLIC_DATA_
#define PUBLIC_DATA_

typedef struct pos_ang {
  int posX;
  int posY;
  int ang;  //-1 = -45deg ; 0 = vertical; 1 = +45deg
} POS_ANG;

extern int button_state_0;
extern int button_state_1;
extern int cap_position;
extern int oneshot_time;
extern struct pos_ang pos_ang_Data;

extern int testt0;
extern int testt1;
extern int testt2;
extern int testt3;
extern int testt4;

#endif

/***************************************************************************//**
 * Initialize blink example
 ******************************************************************************/
void task_init(void);


#endif  // TASKS_H
