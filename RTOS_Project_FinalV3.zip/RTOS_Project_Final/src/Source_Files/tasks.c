/***************************************************************************//**
 * @file
 * @brief Blink examples functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

#include "tasks.h"
#include "sl_simple_led.h"
#include "sl_simple_led_instances.h"
#include "os.h"

/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

static OS_TCB physics_tcb;
static OS_TCB button_tcb;
static OS_TCB capsense_tcb;
static OS_TCB lcd_tcb;
static OS_TCB led_tcb;

static CPU_STK physics_stack[NORMAL_TASK_STACK_SIZE];
static CPU_STK button_stack[NORMAL_TASK_STACK_SIZE];
static CPU_STK capsense_stack[NORMAL_TASK_STACK_SIZE];
static CPU_STK lcd_stack[NORMAL_TASK_STACK_SIZE];
static CPU_STK led_stack[NORMAL_TASK_STACK_SIZE];

OS_SEM Physics_Timer_Semaphore;
OS_SEM Capsense_Timer_Semaphore;
OS_SEM LCD_Timer_Semaphore;
OS_SEM LED_Timer_Semaphore;

OS_MUTEX Button_State_Mutex;
OS_MUTEX Cap_Pos_Mutex;
OS_MUTEX Pos_Ang_Data_Mutex;
OS_MUTEX Oneshot_Time_Mutex;

OS_FLAG_GRP Button_Flags;

OS_TMR  Cap_and_LCD_Timer;
OS_TMR  Physics_Timer;
OS_TMR  LED_Timer;
OS_TMR  Oneshot;

#define  BUTTON_FLAG_0_on         0x1
#define  BUTTON_FLAG_1_on         0x2
#define  BUTTON_FLAG_0_off        0x4
#define  BUTTON_FLAG_1_off        0x8
#define  BUTTON_FLAG_ALL          (BUTTON_FLAG_0_on | BUTTON_FLAG_1_on | BUTTON_FLAG_0_off | BUTTON_FLAG_1_off)

#define LED_THRUST_ON_FLAG        0x1 //tells LED task that thrust is on!
#define LED_THRUST_OFF_FLAG       0x2 //tells LED task that thrust is off!
#define LED_BLACKOUT_FLAG         0x4 //tells LED that we are blacked out, baby
#define LED_WIN_FLAG              0x8 //tells LED that we won!!
#define LED_CRASH_FLAG            0x16 //tells LED that we died. :-(
#define LED_FLAG_ALL              (LED_THRUST_ON_FLAG | LED_THRUST_OFF_FLAG | LED_BLACKOUT_FLAG | LED_WIN_FLAG | LED_CRASH_FLAG)

/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/
static void physics_task(void *arg);
static void button_task(void *arg);
static void capsense_task(void *arg);
static void lcd_task(void *arg);
static void led_task(void *arg);
void physics_TimerCallback(void  *p_tmr, void  *p_arg);
void cap_and_lcd_TimerCallback(void  *p_tmr, void  *p_arg);
void led_TimerCallback(void  *p_tmr, void  *p_arg);
void oneshot_TimerCallback(void  *p_tmr, void  *p_arg);

/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/
unsigned int pushb0;
unsigned int pushb1;
unsigned int capsense_loc;

/***************************************************************************//**
 * Initialize blink example.
 ******************************************************************************/
void task_init(void)
{
  RTOS_ERR err;

  ///Create Tasks
  OSTaskCreate(&physics_tcb,
               "Physics Task",
               physics_task,
               DEF_NULL,
               PHYSICS_TASK_PRIO,
               &physics_stack[0],
               (NORMAL_TASK_STACK_SIZE / 10u),
               NORMAL_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTaskCreate(&button_tcb,
               "Button Task",
               button_task,
               DEF_NULL,
               BUTTON_TASK_PRIO,
               &button_stack[0],
               (NORMAL_TASK_STACK_SIZE / 10u),
               NORMAL_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTaskCreate(&capsense_tcb,
               "Capsense Task",
               capsense_task,
               DEF_NULL,
               CAPSENSE_TASK_PRIO,
               &capsense_stack[0],
               (NORMAL_TASK_STACK_SIZE / 10u),
               NORMAL_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTaskCreate(&lcd_tcb,
               "LCD Task",
               lcd_task,
               DEF_NULL,
               LCD_TASK_PRIO,
               &lcd_stack[0],
               (NORMAL_TASK_STACK_SIZE / 10u),
               NORMAL_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSTaskCreate(&led_tcb,
               "LED Task",
               led_task,
               DEF_NULL,
               LED_TASK_PRIO,
               &led_stack[0],
               (NORMAL_TASK_STACK_SIZE / 10u),
               NORMAL_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  ///Create OS Objects
  OSSemCreate(&Physics_Timer_Semaphore,
              "Physics Timer Semaphore",
              0,
              &err);

  OSSemCreate(&LCD_Timer_Semaphore,
              "LCD Timer Semaphore",
              0,
              &err);

  OSSemCreate(&LED_Timer_Semaphore,
              "LED Timer Semaphore",
              0,
              &err);

  OSSemCreate(&Capsense_Timer_Semaphore,
              "Capsense Timer Semaphore",
              0,
              &err);

  OSMutexCreate(&Button_State_Mutex,
                "Button Presses Data Mutex",
                &err);

  OSMutexCreate(&Cap_Pos_Mutex,
                "Capsense Position Data Mutex",
                &err);

  OSMutexCreate(&Pos_Ang_Data_Mutex,
                "Position and Angle Data Mutex",
                &err);

  OSMutexCreate(&Oneshot_Time_Mutex,
                "Oneshot Time Mutex",
                &err);

  OSFlagCreate(&Button_Flags,
               "Button Task Flags",
               0,
               &err);

  OSTmrCreate(&Physics_Timer,                 /*   Pointer to user-allocated timer.     */
              "Physics Task Post Timer",      /*   Name used for debugging.             */
              1,                              /*     0 initial delay.                   */
              1,                              /*   100 ms period.              */            ///MAY HAVE TO BE ADJUSTED
              OS_OPT_TMR_PERIODIC,            /*   Timer is periodic.                   */
              &physics_TimerCallback,            /*   Called when timer expires.           */
              DEF_NULL,                       /*   No arguments to callback.            */
              &err);

  OSTmrCreate(&Cap_and_LCD_Timer,             /*   Pointer to user-allocated timer.     */
              "Capsense and LCD Post Timer",  /*   Name used for debugging.             */
              1,                              /*     0 initial delay.                   */
              5,                              /*   100 Timer Ticks period.              */            ///MAY HAVE TO BE ADJUSTED
              OS_OPT_TMR_PERIODIC,            /*   Timer is periodic.                   */
              &cap_and_lcd_TimerCallback,            /*   Called when timer expires.           */
              DEF_NULL,                       /*   No arguments to callback.            */
              &err);

  OSTmrCreate(&LED_Timer,
              "LED Timer",
              1,
              10, //starts at 1 second
              OS_OPT_TMR_PERIODIC,
              &led_TimerCallback,
              DEF_NULL,
              &err);

  OSTmrCreate(&Oneshot,
              "LED Oneshot",
              100, // this hopefully wont call the cb.
              0,
              OS_OPT_TMR_ONE_SHOT,
              &oneshot_TimerCallback,
              DEF_NULL,
              &err);

  ///Initialization
  // LED
  GPIO_DriveStrengthSet(BSP_GPIO_LED0_PORT, gpioDriveStrengthStrongAlternateStrong);
  GPIO_DriveStrengthSet(BSP_GPIO_LED1_PORT, gpioDriveStrengthStrongAlternateStrong);
  GPIO_PinModeSet(BSP_GPIO_LED0_PORT, BSP_GPIO_LED0_PIN, gpioModePushPull, false);
  GPIO_PinModeSet(BSP_GPIO_LED1_PORT, BSP_GPIO_LED1_PIN, gpioModePushPull, false);
  // Buttons
  GPIO_PinModeSet(BSP_GPIO_PB0_PORT, BSP_GPIO_PB0_PIN, gpioModeInput, false);
//  GPIO_PinModeSet(BSP_GPIO_PB1_PORT, BSP_GPIO_PB1_PIN, gpioModeInput, false);
  GPIO_IntConfig(PUSHB0_port, PUSHB0_pin, true, true, true);
//  GPIO_IntConfig(PUSHB1_port, PUSHB1_pin, true, true, true);
  NVIC_EnableIRQ(GPIO_EVEN_IRQn);
//  NVIC_EnableIRQ(GPIO_ODD_IRQn);
  // Capsense init located in capsense task
}

/*******************************************************************************
 **************************   TASK FUNCTIONS   *******************************
 ******************************************************************************/
static void physics_task(void *arg) {
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;

  OSTmrStart(&Physics_Timer, &err);

  int oneshot_time_private;

  int button_state_curr;
  int cap_position_curr;

  int velocity_X_curr;
  int velocity_Y_curr;
  int mass_curr;

  int time_since_no_thrust = 0;
  int time_left_blackedout = 0;
  int blackedout = 0;
  int won = 0;
  int lost = 0;

  int velocity_X_prev = INITIAL_V_X;
  int velocity_Y_prev = INITIAL_V_Y;
  int mass_prev = INITIAL_FUEL_MASS + VEHICLE_MASS;

  while (1){ //100 ms have passed since last loop
      OSSemPend(&Physics_Timer_Semaphore,
                          0,
                          OS_OPT_PEND_BLOCKING,
                          DEF_NULL,
                          &err);

      testt0 += 1;
      ///
      /// UPDATE IF WE ARE BLACKED OUT
      ///
      if ((blackedout == 1) && (time_left_blackedout > 0)) { //we just spent 100 ms blackedout
          time_left_blackedout -= 100;
      }
      if ((blackedout == 1) && (time_left_blackedout <= 0)) { //we just woke up
          blackedout = 0;
          //create new timer
          OSTmrDel(&LED_Timer, &err);
          OSTmrCreate(&LED_Timer,
                      "LED Timer",
                      1,
                      10, // 1 hz now that we are awake
                      OS_OPT_TMR_PERIODIC,
                      &led_TimerCallback,
                      DEF_NULL,
                      &err);
          OSTmrStart(&LED_Timer, &err);
          ///Pend mutex oneshot time
          OSMutexPend(&Oneshot_Time_Mutex,
                      0,
                      OS_OPT_PEND_BLOCKING,
                      DEF_NULL,
                      &err);

                oneshot_time = 1;

          OSMutexPost(&Oneshot_Time_Mutex,
                      OS_OPT_POST_NONE,
                      &err);
      }

      ///
      /// IF WE ARENT BLACKED OUT WE CAN TAKE USER INPUT
      ///
      if (blackedout == 0) { //if we arent blacked out, get user input
          /// Pend on Button State Mutex
          OSMutexPend(&Button_State_Mutex,
                      0,
                      OS_OPT_PEND_BLOCKING,
                      DEF_NULL,
                      &err);

          ///   Read Button State
                button_state_curr = button_state_0;

          /// Post Button State Mutex
          OSMutexPost(&Button_State_Mutex,
                      OS_OPT_POST_NONE,
                      &err);

          /// Pend on Cap State Mutex
          OSMutexPend(&Cap_Pos_Mutex,
                      0,
                      OS_OPT_PEND_BLOCKING,
                      DEF_NULL,
                      &err);

          ///   Read Cap State
                cap_position_curr = cap_position;

          /// Post Cap State Mutex
          OSMutexPost(&Cap_Pos_Mutex,
                      OS_OPT_POST_NONE,
                      &err);

          /// Check Blackout
          if (button_state_curr == 0) {
              time_since_no_thrust += 100; // 100 ms
              oneshot_time_private = (time_since_no_thrust * 10 / MAX_ACC_BLACKOUT_AFTER);
              testt1 = oneshot_time_private;
              if(oneshot_time_private <= 0) {oneshot_time_private = 1;}
              ///Pend mutex oneshot time
              OSMutexPend(&Oneshot_Time_Mutex,
                          0,
                          OS_OPT_PEND_BLOCKING,
                          DEF_NULL,
                          &err);

                    oneshot_time = oneshot_time_private;

              OSMutexPost(&Oneshot_Time_Mutex,
                          OS_OPT_POST_NONE,
                          &err);
          }
          else if (button_state_curr == 1) {
              time_since_no_thrust = 0;
              ///Pend mutex oneshot time
              OSMutexPend(&Oneshot_Time_Mutex,
                          0,
                          OS_OPT_PEND_BLOCKING,
                          DEF_NULL,
                          &err);

                    oneshot_time = 1;

              OSMutexPost(&Oneshot_Time_Mutex,
                          OS_OPT_POST_NONE,
                          &err);
          }

          if (time_since_no_thrust >= MAX_ACC_BLACKOUT_AFTER) { //we have just blacked out
              time_since_no_thrust = 0;
              blackedout = 1;
              time_left_blackedout = BLACKOUT_DURATION;

              // create new timer
              OSTmrDel(&LED_Timer, &err);
              OSTmrCreate(&LED_Timer,
                          "LED Timer",
                          1,
                          3, // 3 hz now that we are blacked out
                          OS_OPT_TMR_PERIODIC,
                          &led_TimerCallback,
                          DEF_NULL,
                          &err);
              OSTmrStart(&LED_Timer, &err);
              GPIO_PinOutSet(LED0_port, LED0_pin); //turn on for now
              ///Pend mutex oneshot time
              OSMutexPend(&Oneshot_Time_Mutex,
                          0,
                          OS_OPT_PEND_BLOCKING,
                          DEF_NULL,
                          &err);

                    oneshot_time = 2;

              OSMutexPost(&Oneshot_Time_Mutex,
                          OS_OPT_POST_NONE,
                          &err);
          }
      }


      /// Calculate New Position
      ///   Use Previous Velocity
      /// Calculate New Velocity
      ///   Use Previous Velocity, Updated Weight, Updated Acceleration Vector, 100ms dt
      ///
      /// Check Win/Loss Conditions
      /// If Won/Lost, create new periodic timer and update global VAR for LED
      /// Else If blacked out, create new periodic timer and update global VAR for LED
      /// Else update global VAR for LED
      ///
      /// Pend on Position Data Mutex
      ///   Update Position and Angle Data
      /// Post Position Data Mutex
      ///
  }
}

static void button_task(void *arg) {
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;

  OS_FLAGS flags;
  int button_state_0_private = 1; //1 is unpressed

  while (1) {
      /// Pend on button flags
      flags = OSFlagPend(&Button_Flags,
                         BUTTON_FLAG_ALL,
                         0,
                         OS_OPT_PEND_FLAG_SET_ANY +
                         OS_OPT_PEND_BLOCKING     +
                         OS_OPT_PEND_FLAG_CONSUME,
                         DEF_NULL,
                         &err);

      /// Find Button State
      if      (flags == BUTTON_FLAG_0_on)  button_state_0_private = 0; //0 is pressed
      else if (flags == BUTTON_FLAG_0_off) button_state_0_private = 1; //1 is unpressed

      if((flags == BUTTON_FLAG_0_on) || (flags == BUTTON_FLAG_0_off)) {
          /// Pend on Button State Mutex
          OSMutexPend(&Button_State_Mutex,
                      0,
                      OS_OPT_PEND_BLOCKING,
                      DEF_NULL,
                      &err);

          ///   Update Button State
                button_state_0 = button_state_0_private;

          /// Post Button State Mutex
          OSMutexPost(&Button_State_Mutex,
                      OS_OPT_POST_NONE,
                      &err);
      }
  }
}

static void capsense_task(void *arg) {
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;

  OSTmrStart(&Cap_and_LCD_Timer, &err);
  CAPSENSE_Init();

  unsigned int cap_position_private;

  while (1){
      /// Pend on Cap Timer Sem
      OSSemPend(&Capsense_Timer_Semaphore,
                0,
                OS_OPT_PEND_BLOCKING,
                DEF_NULL,
                &err);

      /// Find Cap State
      cap_position_private = get_capsense_loc();
      if(cap_position_private == 3) {
          cap_position_private--; //if the right-most pad is working, just use it as an extention to the slight-right pad. I only use 3 orientations.
      }

      /// Pend on Cap State Mutex
      OSMutexPend(&Cap_Pos_Mutex,
                  0,
                  OS_OPT_PEND_BLOCKING,
                  DEF_NULL,
                  &err);

      ///   Update Cap State
            cap_position = cap_position_private;
      /// Post Cap State Mutex
      OSMutexPost(&Cap_Pos_Mutex,
                  OS_OPT_POST_NONE,
                  &err);
  }
}

static void lcd_task(void *arg) {
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;

  while (1){
      /// Pend on LCD Timer Sem
      OSSemPend(&LCD_Timer_Semaphore,
                0,
                OS_OPT_PEND_BLOCKING,
                DEF_NULL,
                &err);

      /// Pend on Position Data Mutex
      ///   Read and keep Position Data
      /// Post Position Data Mutex
      /// Draw ??
      ///
      /// LCD (0,0) is TOP LEFT
      ///   Y increases from top to bottom
      ///   X increases from left to right
  }
}

static void led_task(void *arg) {
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;

  OSTmrStart(&LED_Timer, &err);

  OS_TICK oneshot_length = 1;

  while (1){
      /// Pend on LED Flags
      OSSemPend(&LED_Timer_Semaphore,
                0,
                OS_OPT_PEND_BLOCKING,
                DEF_NULL,
                &err);

      GPIO_PinOutSet(LED0_port, LED0_pin); //turn on LED

      ///MUTEX TO GLOBAL VAR
      OSMutexPend(&Oneshot_Time_Mutex,
                  0,
                  OS_OPT_PEND_BLOCKING,
                  DEF_NULL,
                  &err);

            oneshot_length = oneshot_time;

      OSMutexPost(&Oneshot_Time_Mutex,
                  OS_OPT_POST_NONE,
                  &err);


      OSTmrDel(&Oneshot, &err); //delete and...

      OSTmrCreate(&Oneshot,    // ... recreate oneshot timer
                  "LED Oneshot",
                  oneshot_length,
                  0,
                  OS_OPT_TMR_ONE_SHOT,
                  &oneshot_TimerCallback,
                  DEF_NULL,
                  &err);

      OSTmrStart(&Oneshot, &err);

      /// ???
      ///
      ///
      /// Periodic Timer sends a semaphore to LED ON Task
      /// LED ON Task: 1) turns LED ON 2) activates a oneshot timer that:
      /// Oneshot timer callback turns off LED.
      ///
      /// Physics task will delete and recreate the PEriodic Timer when necessary.
      /// It also needs to update a global var for the ON task so that the ON task knows what length to crate the oneshot timer for.
  }
}


/*******************************************************************************
 **************************   TIMER AND ISR FUNCTIONS   *******************************
 ******************************************************************************/

//Semaphore Timer
void physics_TimerCallback (void  *p_tmr, ///this may need to be a crit sec
                        void  *p_arg) {
  /* Called when timer expires:                            */
  /*   'p_tmr' is pointer to the user-allocated timer.     */
  /*   'p_arg' is argument passed when creating the timer. */
  PP_UNUSED_PARAM(p_tmr);
  PP_UNUSED_PARAM(p_arg);
  RTOS_ERR err;

  OSSemPost (&Physics_Timer_Semaphore,
             OS_OPT_POST_ALL,
             &err);
}

void cap_and_lcd_TimerCallback (void *p_tmr, //this may need to be a crit sec
                                void *p_arg) {
  /* Called when timer expires:                            */
  /*   'p_tmr' is pointer to the user-allocated timer.     */
  /*   'p_arg' is argument passed when creating the timer. */
  PP_UNUSED_PARAM(p_tmr);
  PP_UNUSED_PARAM(p_arg);
  RTOS_ERR err;

  OSSemPost (&LCD_Timer_Semaphore,
             OS_OPT_POST_ALL,
             &err);

  OSSemPost (&Capsense_Timer_Semaphore,
             OS_OPT_POST_ALL,
             &err);
}

void led_TimerCallback (void *p_tmr, //this may need to be a crit sec
                        void *p_arg) {
  /* Called when timer expires:                            */
  /*   'p_tmr' is pointer to the user-allocated timer.     */
  /*   'p_arg' is argument passed when creating the timer. */
  PP_UNUSED_PARAM(p_tmr);
  PP_UNUSED_PARAM(p_arg);
  RTOS_ERR err;

  OSSemPost (&LED_Timer_Semaphore,
             OS_OPT_POST_ALL,
             &err);
}

void oneshot_TimerCallback (void *p_tmr, //this may need to be a crit sec
                            void *p_arg) {
  /* Called when timer expires:                            */
  /*   'p_tmr' is pointer to the user-allocated timer.     */
  /*   'p_arg' is argument passed when creating the timer. */
  PP_UNUSED_PARAM(p_tmr);
  PP_UNUSED_PARAM(p_arg);

  GPIO_PinOutClear(LED0_port, LED0_pin); //turn off LED
}

//GPIO Interrupts
void GPIO_EVEN_IRQHandler(void){
  uint32_t temp = GPIO_IntGet();
  GPIO_IntClear(temp);
  RTOS_ERR  err;

  unsigned int gpio_func_output = GPIO_PinInGet(BSP_GPIO_PB0_PORT, BSP_GPIO_PB0_PIN); //this returns 0 if button is pressed, 1 if not pressed

  /// SEND FLAG TO BUTTON TASK telling if it is a rising or falling edge
  if(gpio_func_output == 1) { //button is now unpressed
      GPIO_PinOutClear(LED1_port, LED1_pin);
      OSFlagPost(&Button_Flags,
                 BUTTON_FLAG_0_off,
                 OS_OPT_POST_FLAG_SET,
                 &err);
  }
  else if(gpio_func_output == 0) { //button is now pressed
      GPIO_PinOutSet(LED1_port, LED1_pin);
      OSFlagPost(&Button_Flags,
                 BUTTON_FLAG_0_on,
                 OS_OPT_POST_FLAG_SET,
                 &err);
  }
}

//void GPIO_ODD_IRQHandler(void){ //this function is only different from the last one in that it calls a function, i just copied that functions logic into the other gpio interrupt handler
//  uint32_t temp = GPIO_IntGet();
//  GPIO_IntClear(temp);
//  RTOS_ERR  err;
//
//  ///CHANGE THIS TO FLAG SYSTEM
//  //*** Post Semaphore to Speed Setpoint Task
////  OSSemPost (&,
////             OS_OPT_POST_ALL,
////             &err);
//}


