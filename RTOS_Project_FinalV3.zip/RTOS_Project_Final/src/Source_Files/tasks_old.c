/***************************************************************************//**
 * @file
 * @brief Blink examples functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/


/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/
#ifdef tasks_old_on
static OS_TCB button_tcb;
static CPU_STK button_stack[BUTTON_TASK_STACK_SIZE];

static OS_TCB slider_tcb;
static CPU_STK slider_stack[SLIDER_TASK_STACK_SIZE];

static OS_TCB led_tcb;
static CPU_STK led_stack[LED_TASK_STACK_SIZE];

static OS_TCB idle_tcb;
static CPU_STK idle_stack[IDLE_TASK_STACK_SIZE];

static OS_Q Led_MessageQ;

OS_FLAG_GRP  V_Monitor_Flags;

#define  BUTTON_FLAG_0_on         0x1
#define  BUTTON_FLAG_1_on         0x2
#define  BUTTON_FLAG_0_off        0x4
#define  BUTTON_FLAG_1_off        0x8
#define  BUTTON_FLAG_ALL          (BUTTON_FLAG_0_on | BUTTON_FLAG_1_on | BUTTON_FLAG_0_off | BUTTON_FLAG_1_off)

OS_SEM  Vehicle_Semaphore;

OS_TMR  task_Timer;

/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/
static void button_task(void *arg);
static void slider_task(void *arg);
static void led_task(void *arg);
static void idle_task(void *arg);
void task_TimerCallback (void  *p_tmr, void  *p_arg);
/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/
unsigned int pushb0;
unsigned int pushb1;
unsigned int capsense_loc;
/***************************************************************************//**
 * Initialize blink example.
 ******************************************************************************/
void task_init(void)
{
  RTOS_ERR err;

  // Create Button Task
  OSTaskCreate(&button_tcb,
               "button task",
               button_task,
               DEF_NULL,
               BUTTON_TASK_PRIO,
               &button_stack[0],
               (BUTTON_TASK_STACK_SIZE / 10u),
               BUTTON_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  // Create Slider Task
  OSTaskCreate(&slider_tcb,
               "slider task",
               slider_task,
               DEF_NULL,
               SLIDER_TASK_PRIO,
               &slider_stack[0],
               (SLIDER_TASK_STACK_SIZE / 10u),
               SLIDER_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

// Create LED Task
  OSTaskCreate(&led_tcb,
               "led task",
               led_task,
               DEF_NULL,
               LED_TASK_PRIO,
               &led_stack[0],
               (LED_TASK_STACK_SIZE / 10u),
               LED_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

// Create Idle Task
  OSTaskCreate(&idle_tcb,
               "idle task",
               idle_task,
               DEF_NULL,
               IDLE_TASK_PRIO,
               &idle_stack[0],
               (IDLE_TASK_STACK_SIZE / 10u),
               IDLE_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  /* Create a periodic timer.               */
  OSTmrCreate(&task_Timer,             /*   Pointer to user-allocated timer.     */
              "Semaphore Post Timer", /*   Name used for debugging.             */
              1,                      /*     0 initial delay.                   */
              5,                    /*   100 Timer Ticks period.              */            ///MAY HAVE TO BE ADJUSTED
              OS_OPT_TMR_PERIODIC,    /*   Timer is periodic.                   */
              &task_TimerCallback,     /*   Called when timer expires.           */
              DEF_NULL,               /*   No arguments to callback.            */
              &err);

  OSFlagCreate(&V_Monitor_Flags,
               "Button Flags",
               0,
               &err);

  OSSemCreate(&Vehicle_Semaphore,
              "Slider Semaphore",
              0,
              &err);
}

/***************************************************************************//**
 * Button task.
 ******************************************************************************/
static void button_task(void *arg){
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    LED_MSG msg;
    OS_FLAGS flags;

    //initialization
    GPIO_PinModeSet(BSP_GPIO_PB0_PORT, BSP_GPIO_PB0_PIN, gpioModeInput, false);
    GPIO_PinModeSet(BSP_GPIO_PB1_PORT, BSP_GPIO_PB1_PIN, gpioModeInput, false);

    GPIO_IntConfig(PUSHB0_port, PUSHB0_pin, true, true, true);
    GPIO_IntConfig(PUSHB1_port, PUSHB1_pin, true, true, true);

    NVIC_EnableIRQ(GPIO_EVEN_IRQn);
    NVIC_EnableIRQ(GPIO_ODD_IRQn);

    while (1){
        OSTimeDly(10, OS_OPT_TIME_DLY, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        /* Wait until any flag is set.             */
        flags = OSFlagPend(&V_Monitor_Flags,            /*   Pointer to user-allocated event flag. */
                           BUTTON_FLAG_ALL,          /*   Flag bitmask to match.                */
                           0,                      /*   Wait for 100 OS Ticks maximum.        */    ///THIS MAY BE WRONG
                           OS_OPT_PEND_FLAG_SET_ANY +/*   Wait until any flag is set and        */
                           OS_OPT_PEND_BLOCKING     +
                           OS_OPT_PEND_FLAG_CONSUME/*    task will block and                  */
                           , /*    function will clear the flags.       */
                           DEF_NULL,                 /*   Timestamp is not used.                */
                           &err);

        //handle flag output (meaning that one or more flags set)
        msg.cap = -1;     //unused, this isnt the cap sensor
        msg.button0 = -1; //in case none of the if statements below get triggered
        msg.button1 = -1; //ditto above

        if(flags == 0x3) {
            msg.button0 = 0;
            msg.button1 = 0;
        }
        else if(flags == BUTTON_FLAG_0_on) {
            msg.button0 = 1;
            msg.button1 = 0;
        }
        else if (flags == BUTTON_FLAG_1_on){
            msg.button0 = 0;
            msg.button1 = 1;
        }
        else if (flags == BUTTON_FLAG_0_off) {
            msg.button0 = 0;
            msg.button1 = 0;
        }
        else if (flags == BUTTON_FLAG_1_off) {
            msg.button0 = 0;
            msg.button1 = 0;
        }

        /* Send message to the waiting task. */
        OSQPost(&Led_MessageQ,                /*   Pointer to user-allocated message queue.       */
                (void *)&msg,                 /*   The message is a pointer to the APP_MESSAGE.   */
                (OS_MSG_SIZE)sizeof(void *),  /*   Size of the message is the size of a pointer.  */
                OS_OPT_POST_FIFO,             /*   Add message at the end of the queue.           */
                &err);
        if (err.Code != RTOS_ERR_NONE) {
            /* Handle error on message queue post. */
        }

    }
}

/***************************************************************************//**
 * Slider task.
 ******************************************************************************/
static void slider_task(void *arg){
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    LED_MSG msg;
    OS_SEM_CTR  ctr;
    OSTmrStart(&task_Timer, &err);

    CAPSENSE_Init();

    while (1){
        OSTimeDly(10, OS_OPT_TIME_DLY, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        /* Acquire resource protected by semaphore.        */
        ctr = OSSemPend(&Vehicle_Semaphore,    /* Pointer to user-allocated semaphore.    */
                        0,                    /* Wait for a maximum of 1000 OS Ticks.    */
                        OS_OPT_PEND_BLOCKING, /* Task will block.                        */
                        DEF_NULL,             /* Timestamp is not used.                  */
                        &err);

        //semaphore posted
        msg.button0 = -1; //unused
        msg.button1 = -1; //unused
        msg.cap = get_capsense_loc();

        /* Send message to the waiting task. */
        OSQPost(&Led_MessageQ,                /*   Pointer to user-allocated message queue.       */
                (void *)&msg,                 /*   The message is a pointer to the APP_MESSAGE.   */
                (OS_MSG_SIZE)sizeof(void *),  /*   Size of the message is the size of a pointer.  */
                OS_OPT_POST_FIFO,             /*   Add message at the end of the queue.           */
                &err);
        if (err.Code != RTOS_ERR_NONE) {
            /* Handle error on message queue post. */
        }
    }
}

/***************************************************************************//**
 * LED task.
 ******************************************************************************/
static void led_task(void *arg){
    PP_UNUSED_PARAM(arg);
    RTOS_ERR      err;
    void         *p_raw_msg;
    OS_MSG_SIZE   msg_size;
    LED_MSG      *p_msg;
    int button0_last = 0;
    int button1_last = 0;
    int cap_last = 4;

    //initialization
    GPIO_DriveStrengthSet(BSP_GPIO_LED0_PORT, gpioDriveStrengthStrongAlternateStrong);
    GPIO_DriveStrengthSet(BSP_GPIO_LED1_PORT, gpioDriveStrengthStrongAlternateStrong);
    //  GPIO_DriveStrengthSet(LED1_port, gpioDriveStrengthWeakAlternateWeak);
    //  GPIO_DriveStrengthSet(LED0_port, gpioDriveStrengthWeakAlternateWeak);

    GPIO_PinModeSet(BSP_GPIO_LED0_PORT, BSP_GPIO_LED0_PIN, gpioModePushPull, false);
    GPIO_PinModeSet(BSP_GPIO_LED1_PORT, BSP_GPIO_LED1_PIN, gpioModePushPull, false);


    /* Create the message queue.                           */
    OSQCreate(&Led_MessageQ,    /*   Pointer to user-allocated message queue.          */
              "Led MessageQ",   /*   Name used for debugging.                          */
              10,               /*   Queue will have 10 messages maximum.              */
              &err);
    if (err.Code != RTOS_ERR_NONE) {
        /* Handle error on message queue create. */
    }
    while (1){
        OSTimeDly(10, OS_OPT_TIME_DLY, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        /* Wait until task receives a message.        */
        p_raw_msg = OSQPend(&Led_MessageQ,          /*   Pointer to user-allocated message queue. */
                            0,                   /*   Wait for 100 OS Ticks maximum.           */
                            OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                            &msg_size,              /*   Will contain size of message in bytes.   */
                            DEF_NULL,              /*   Timestamp is not used.                   */
                            &err);

        p_msg = (LED_MSG *)p_raw_msg;

        // set_ledX(buttonX_val, cap_val)
        //    buttonX_val = -1 for ??
        //                  0  for LEDX off if no cap
        //                  1  for LEDX on
        //
        //    cap_val     = -1 for ??
        //                  0  for LED0 on
        //                  1  for LED1 on
        //                  2  for LEDX ??
        //
        //

        //cases that msg is from cap
        if ((p_msg->cap < 2) && (p_msg->cap != -1)) {
            //case: new cap left side
            set_led0(1);
        }
        else if ((p_msg->cap >= 2) && (p_msg->cap < 4)) {
            //case: new cap right side
            set_led1(1);
        }
        else if (p_msg->cap == 4) {
            //case: new cap is OFF
            //      ->if buttons were on, set LED to that
            set_led0(button0_last);
            set_led1(button1_last);
        }

        //cases that msg is from button ;; given: something must have changed
        else if ((button0_last == 1 && p_msg->button1 == 1) ||
                 (button1_last == 1 && p_msg->button0 == 1)) {
            //case: both buttons pressed
            //      ->if cap_last is on then make sure LEDS are set to cap value

            // change buttons last to off
            button0_last = 5;
            button1_last = 5;

            if((cap_last < 2) && (cap_last !=-1)) {
                set_led0(1);
                set_led1(0);
            }
            else if((cap_last >= 2) && (cap_last < 4)) {
                set_led0(0);
                set_led1(1);
            }
            else if(cap_last == 4) {
                set_led0(0);
                set_led1(0);
            }
        }

        else if (p_msg->button0 == 1) {
            //case: button0 pressed
            set_led0(1);
        }
        else if (p_msg->button1 == 1) {
            //case: button1 pressed
            set_led1(1);
        }
        else {
            set_led0(0);
            set_led1(0);
        }

        //update new lasts
        if (button0_last == 5) {
            button0_last = 0;
        }
        else if (p_msg->button0 != -1) {
            button0_last = p_msg->button0;
        }
        if (button1_last == 5) {
            button1_last = 0;
        }
        else if (p_msg->button1 != -1) {
            button1_last = p_msg->button1;
        }
        if (p_msg->cap != -1) {
            cap_last = p_msg->cap;
        }
    }
}

static void idle_task(void *arg){
    PP_UNUSED_PARAM(arg);

    RTOS_ERR err;

    while (1){
        OSTimeDly(100, OS_OPT_TIME_DLY, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        EMU_EnterEM1();
    }
}

//Semaphore Timer
void task_TimerCallback (void  *p_tmr,
                        void  *p_arg) {
  /* Called when timer expires:                            */
  /*   'p_tmr' is pointer to the user-allocated timer.     */
  /*   'p_arg' is argument passed when creating the timer. */
  PP_UNUSED_PARAM(p_tmr);
  PP_UNUSED_PARAM(p_arg);
  RTOS_ERR err;

  OSSemPost (&Vehicle_Semaphore,
             OS_OPT_POST_ALL,
             &err);
}
//GPIO Interrupts
void GPIO_EVEN_IRQHandler(void){
  uint32_t temp = GPIO_IntGet();
  GPIO_IntClear(temp);

  int temp2 = get_pushb0();
  RTOS_ERR  err;
  OS_FLAGS  flags;

  if(temp2 == 1) {//pushb0 is pushed down
      /* Set Application Flag B.                    */
      flags = OSFlagPost(&V_Monitor_Flags,           /*   Pointer to user-allocated event flag.    */  ///THIS MAY NOT WORK
                         BUTTON_FLAG_0_on,               /*   Application Flag B bitmask.              */
                         OS_OPT_POST_FLAG_SET,    /*   Set the flag.                            */
                         &err);
  }
  else { //pushb0 is not pushed down
      /* Set Application Flag B.                    */
      flags = OSFlagPost(&V_Monitor_Flags,           /*   Pointer to user-allocated event flag.    */  ///THIS MAY NOT WORK
                         BUTTON_FLAG_0_off,               /*   Application Flag B bitmask.              */
                         OS_OPT_POST_FLAG_SET,    /*   Set the flag.                            */
                         &err);
  }
}

void GPIO_ODD_IRQHandler(void){ //this function is only different from the last one in that it calls a function, i just copied that functions logic into the other gpio interrupt handler
  uint32_t temp = GPIO_IntGet();
  GPIO_IntClear(temp);

  int temp2 = get_pushb1();
  RTOS_ERR  err;
  OS_FLAGS  flags;

  if(temp2 == 1) { //pushb1 is pushed down
      /* Set Application Flag B.                    */
      flags = OSFlagPost(&V_Monitor_Flags,           /*   Pointer to user-allocated event flag.    */  ///THIS MAY NOT WORK
                         BUTTON_FLAG_1_on,               /*   Application Flag B bitmask.              */
                         OS_OPT_POST_FLAG_SET,    /*   Set the flag.                            */
                         &err);
  }
  else { //pushb1 is not pressed
      /* Set Application Flag B.                    */
      flags = OSFlagPost(&V_Monitor_Flags,           /*   Pointer to user-allocated event flag.    */  ///THIS MAY NOT WORK
                         BUTTON_FLAG_1_off,               /*   Application Flag B bitmask.              */
                         OS_OPT_POST_FLAG_SET,    /*   Set the flag.                            */
                         &err);
  }
}

#endif
